This directory will contain your static images for Flask. Copy all images from your previous images/ directory here.
